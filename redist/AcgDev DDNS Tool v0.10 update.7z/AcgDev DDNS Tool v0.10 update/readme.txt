需要安装 .Net9 运行时：
[英文页面] https://dotnet.microsoft.com/en-us/download/dotnet/9.0
[中文页面] https://dotnet.microsoft.com/zh-cn/download/dotnet/9.0

（ddns_server 的环境也需要安装 .Net9，否则会启动失败）